#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// #include <errno.h>

int main(int argc, char** argv){

    int err = 0;
    int secerr = 0;
    char debugmessages[40];
    memset(debugmessages, 0, 40);
    int dbg = 0;
    int i = 0;
    while(dbg == 0 && i<argc){
        if (strcmp(argv[i], "-d") == 0) dbg = 1;
        i++;
    }
    int pip[2];
    if (pipe(pip) == -1) return 1;
    if (dbg) fprintf(stderr, "(parent_process>forking...)\n");
    int pid = fork();
    if (pid == -1) return 2;
    if (pid == 0){
        
        close(1);   // close standard output
        if(dbg) fprintf(stderr, "(child1>redirecting stdout to the write end of the pipe...)\n");
        int dupwrite = dup2(pip[1], 1);
        close(pip[1]);
        char* com[] = {"ls","-l", NULL};
        if(dbg) fprintf(stderr, "(child1>going to execute cmd: ls)\n");
        err = execvp(com[0],com);
        if (err == -1) printf("error1\n");
        exit(err);
    }
    else {
        if(dbg) fprintf(stderr, "(parent_process>created process with id: %d)\n", pid);
        if(dbg) fprintf(stderr, "(parent_process>closing the write end of the pipe...)\n");
        close(pip[1]);
        int secpid = fork();
        if(secpid == 0){
            waitpid(pid, &err, 0);
            close(0);     // close standard input
            if(dbg) fprintf(stderr, "(child2>redirecting stdin to the read end of the pipe...)\n");
            int dupread = dup2(pip[0], 0);
            close(pip[0]);
            char* seccom[] = {"tail", "-n", "2"};
            if(dbg) fprintf(stderr, "(child2>going to execute cmd: tail)\n");
            secerr = execvp(seccom[0], seccom);
            if (secerr == -1) printf("error2\n");
            exit(err);
        }
        else{
            if (dbg) fprintf(stderr, "(parent_process>created process with id: %d)\n", secpid);
            if(dbg) fprintf(stderr, "(parent_process>closing the read end of the pipe...)\n");
            close(pip[0]);
            if (dbg) fprintf(stderr, "(parent_process>waiting for child processes to terminate…)\n");
            waitpid(pid, &err, 0);
            waitpid(secpid, &secerr, 0);
            if (dbg) fprintf(stderr, "(parent_process>exiting…)\n");
            exit(0);
        }
    }
}