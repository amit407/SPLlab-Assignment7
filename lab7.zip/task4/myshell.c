#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "LineParser.h"
#include <unistd.h>
#include <limits.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// #include <errno.h>

#define PATH_MAX 4096
#define MAXSIZE 256
#define HISTORYMAXSIZE 4

int nextcommand = 0;

void handlepipeline(cmdLine* c){
    FILE* inp;
    FILE *out;
    printf("inputRedirect is  = %s and outputRedirectory is %s\n", c->inputRedirect, c->next->outputRedirect);
    int err = 0;
    int secerr = 0;
    int pip[2];
    if (pipe(pip) == -1) return;
    int pid = fork();
    if (pid == -1) return;
    if (pid == 0){
        close(1);
        int dupwrite = dup(pip[1]);
        err = execvp(c->arguments[0],c->arguments);
        if (err == -1) printf("error\n");
        exit(err);
    }
    else{
        close(pip[1]);
        int secpid = fork();
        if(secpid == 0){
            cmdLine* c2 = c->next;
            waitpid(pid, &err, 0);
            close(0);
            int dupread = dup(pip[0]);
            printf("pip[0] inputRedirect is = %s\n", c->inputRedirect);
            printf("pip[1] ouputRedirect is = %s\n", c->outputRedirect);

            if (c->inputRedirect != NULL){
                close (0);
                inp = fopen(c->inputRedirect,"r");
                dup(inp->_fileno);
            }
            if( c->next->outputRedirect != NULL){
                close(1);
                out = fopen(c->next->outputRedirect,"w+");
                dup(out->_fileno);
            }
            secerr = execvp(c2->arguments[0], c2->arguments);
            if (secerr == -1) printf("error\n");
            exit(secerr);
        }
        else{

            close(pip[0]);
            waitpid(pid, &err, 0);
            waitpid(secpid, &secerr, 0);
            return;
        }
    }

}

void handleCat(cmdLine* c){
    int argc = c->argCount;
    char* const *argv = c->arguments;
    int inFile = 0;
    int outFile = 1;
    int i;
    for (i = 0; i<argc; i++){
        if (c->inputRedirect != NULL) {
            close(0);
            inFile = open(c->inputRedirect, O_RDONLY, 0777);
            if (inFile == -1) {
                printf("error opening file '%s' for reading\n", c->inputRedirect);
                exit(-1);
            }
        }
        if (c->outputRedirect != NULL) {
            close(1);
            outFile = creat(c->outputRedirect, 0777);
            if (outFile == -1){
                printf("error opening/creating file for '%s' for writing\n", c->outputRedirect);
                exit(-1);
            }
        }
    }
    char buffer[MAXSIZE];
    int bytesread = -1;
    int byteswritten = -1;
    while(1){
        bytesread = read(inFile, buffer, MAXSIZE);
        if (bytesread == -1){
            printf("error reading from file %d\n", inFile);
            close(inFile);
            close(outFile);
            exit(-1);
        }
        byteswritten = write(outFile, buffer, bytesread);
        if (byteswritten == -1){
            printf("error writing to file %d\n", outFile);
            close(inFile);
            close(outFile);
            exit(-1);
        }
        if (bytesread == 0) break;
        memset(buffer, 0, MAXSIZE);
    }
    if (inFile!=0) close(inFile);
    if (outFile!=1) close(outFile);
}


char* handlei(char *com, char** history){
    if (com[1] == '!'){
        int temp = nextcommand-1;
        while (strcmp(history[temp], "history\n") == 0){
            temp = temp-1;
        }
        char *comm = history[temp];
        return comm;
    }
    char *n = com+1;       // !n 
    int num = atoi(n);
    if (num < 0 | num > nextcommand){
        printf(" n = %d out of bound\n", num);
        exit(-1);
    }
    char *comm = history[num];
    return comm;

}

int execute(cmdLine *pCmdLine, char** history){

    int lng = pCmdLine->argCount;
    char *args[lng+1];
    int err;
    if (strcmp(pCmdLine->arguments[0], "cd") == 0){
        if (lng == 1){
            err = chdir(getenv("HOME"));
        }
        else{
            err = chdir(pCmdLine->arguments[1]);
        }
        if (err != 0) fprintf(stderr, "Error changing directory\n");
        return 1;
    }
    else if (strcmp(pCmdLine->arguments[0], "history") == 0){
        int i;
        for (i = 0; i<nextcommand; i++) printf("%d. %s", i, history[i]);
        return 1;
    }
    int pid;
    if (pCmdLine->next != NULL) handlepipeline(pCmdLine);
    else{
        pid = fork();
        if (pid == 0){
            if (strcmp(pCmdLine->arguments[0], "cat") == 0) handleCat(pCmdLine);
            err = execvp(pCmdLine->arguments[0], pCmdLine->arguments);
            if (err != 0){
                    perror("Error ");
                    _exit(err);
                }
            exit(0);
        }
    }
    if(pCmdLine->blocking == '1') waitpid(pid, &err, 0);
    return 1;
}

int main(int argc, char** argv){

    char** history = (char**)malloc(MAXSIZE*sizeof(char*));
    int maxhistorylength = HISTORYMAXSIZE;
    int recall = 0;
    char buffer[PATH_MAX];
    while(1){
        getcwd(buffer, PATH_MAX);
        printf("%s>", buffer);
        char inputline[MAXSIZE];
        char* cmdp = fgets(inputline, MAXSIZE, stdin);
        cmdLine *cmdl;
        char *newcom;
        recall = 0;
        if (cmdp[0] == '!'){
            recall = 1;
            newcom = handlei(cmdp, history);
            cmdl = parseCmdLines(newcom);
        }
        else cmdl = parseCmdLines(cmdp);
        if (strcmp(cmdl->arguments[0], "quit") == 0){
            freeCmdLines(cmdl);
            break;
        }
    
        execute(cmdl, history);
        if (nextcommand == maxhistorylength){
            char** tmp = realloc(history, maxhistorylength*2*sizeof(char*));
            if (tmp == NULL) printf("no space for more commands");
            else {
                history = tmp;
                maxhistorylength = maxhistorylength*2;
            }
        }
        if (recall) {
            history[nextcommand%HISTORYMAXSIZE] = (char*)malloc((strlen(newcom)+1)*(sizeof(char)));
            strcpy(history[nextcommand%HISTORYMAXSIZE], newcom);
        }
        else {
            history[nextcommand%HISTORYMAXSIZE] = (char*)malloc((strlen(cmdp)+1)*(sizeof(char)));
            strcpy(history[nextcommand%HISTORYMAXSIZE], cmdp);
        }
        
        nextcommand++;
        freeCmdLines(cmdl);
    }
    int i;
    for (i=0;i<nextcommand;i++) free(history[i]);
    free(history);
    return 1;
}

